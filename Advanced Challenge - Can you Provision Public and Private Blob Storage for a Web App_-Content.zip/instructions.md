!IMAGE[Advanced.png](Advanced.png)



<h1 align=center> Can you Provision Public and Private Blob Storage for a Web App?</h1>


Click **Next** to get started...
===

#Introduction
##Log on to your Azure account
@lab.UserFirstName, navigate to the Azure Portal at @lab.CloudPortalSignInLink and login as ++@lab.CloudPortalCredential(1).Username++ using the password ++@lab.CloudPortalCredential(1).Password++.  

>You will only be able to create resources in the **@lab.CloudResourceGroup(343).Name** resource group, and you will only be able to create the resources required for this challenge.  The ability to create any other resources has been disallowed by an Azure policy.


##Understand the Scenario
You are a system administrator for a company that is migrating their primary web application from their data center to Azure.  The company needs you to configure storage for various files used by the web application.  The web app is deployed as **lods@lab.LabInstanceId**.  You will create a storage account with  public and private blob containers and upload files to both containers.  You will generate a shared access signature for the private container.  You will test the configuration using a test page provided with the web app.

##Understand your Environment
You are using an Azure resource group.  The resource group contains a preconfigured web site.  The configuration of the web site may not be complete when you begin this challenge.  You will receive a notification when the automated configuration is complete.  Take a moment and familiarize yourself with what you have in the environment.

Here is a table of what you can expect to find.

|||
|:--|:--|
|Resource group | **@lab.CloudResourceGroup(343).Name**  |
|Web app  |**lods001@lab.LabInstanceId**  |


When you are ready, click **Next** to get to work...
===
##Requirement 1: Create a storage account with blob containers
First, you must create a storage account with public and private blob access.

##What to do
Create a storage account named **sa@lab.LabInstanceId** and add a container named ++public++ that is configured for **public blob access** and a container named ++private++ with **private access**.

##Check your Work
You can proceed if the following items are completed:

- [] You have created a storage account named **sa@lab.LabInstanceId**
- [] You have added a container named **public** with public blob access to the storage account
- [] You have added a container named **private** with private access to the storage account

[Stuck?](https://docs.microsoft.com/en-us/azure/storage/ )

If everything works, click **Next** to proceed to **Requirement 2**.

===


##Requirement 2: Upload files to the storage account
Now you need to upload a few files to the storage account.

##What to do
Upload files to both the **public** and **private** containers of the **sa@lab.LabInstanceId** storage account.  At least one of the files in each container must be marked with metadata = ++"source=CloudShell"++.

##Check your work
You can move to requirement 3 if the following items are complete:

- [] You have uploaded more than one file to the **public** and container of the  **sa@lab.LabInstanceId** storage account.
- [] You have uploaded more than one file to the **private** and container of the  **sa@lab.LabInstanceId** storage account.
- [] There is a file with metadata set to **source=CloudShell** in each container.

[Stuck?](https://www.red-gate.com/simple-talk/cloud/platform-as-a-service/azure-blob-storage-part-6-blob-properties-metadata-etc/ )


If everything works, click **Next** to proceed to **Requirement 3**.

===

##Requirement 3: Generate a shared access signature for the private container
Next you will generate a SAS for the **private** container.


##What to do
Generate a read-only SAS for the **private** container.  Make sure the SAS is valid for at least 24 hours (longer is fine).

##Check your work
You can move to requirement 4 if the following items are complete:

- [] You have generated a read-only SAS for the **private** container of the  **sa@lab.LabInstanceId** storage account.

> [!KNOWLEDGE] You can test the SAS using the full URL of one of the files in the **private** container.  Add the SAS to the URL as a query string - add a ? after the file URL followed by the SAS.


[Stuck?](https://docs.microsoft.com/en-us/azure/storage/common/storage-dotnet-shared-access-signature-part-1 )


If the SAS works, click **Next** to proceed to **Requirement 4**.
===

##Requirement 4: Configure the web application to use the storage account

Now you will configure the **lods@lab.LabInstanceId** web app to use the storage account named **sa@lab.LabInstanceId**.

> [!ALERT] 
^[Do not continue until you have received a message that the challenge provisioning is complete.  Click the envelope icon in the lab environment to check your messages.][ContinuanceWarning]


##What to do
Configure the following application settings for the **lods@lab.LabInstanceId** web app:
- StorageAccountName
- StorageAccountKey
- StorageAccountSAS

##Check your work
You can move to requirement 5 if the following items are complete:

- [] You have set the values of the **StorageAccountName, StorageAccountKey**, and **StorageAccountSAS**

[Stuck?](https://docs.microsoft.com/en-us/azure/app-service/web-sites-configure )


If everything is set, click **Next** to proceed to **Requirement 5**.

===

##Requirement 5: Test the web application

Now you will use the web app to confirm the configuration of the storage account.


##What to do

Open the test page at ++https://lods@lab.LabInstanceId.azurewebsites.net/Home/Files++ and click test and observe whether all of your settings are confirmed.

##Check your work
You can move to the challenge summary if:

- [] The web page displays a message that you have successfully configured both the **public** and **private** containers and displays links for all of the files that you uploaded.



If the web app confirms that you have configured your storage account correctly, click **Next** to proceed to **Summary**.

===

##Summary



Congratulations, you have completed the "Can you Provision Public and Private Blob Storage for a Web App?" challenge.   

In this challenge you accomplished the following things:
 - Provisioned Azure storage
 - Created a blob storage container with public blob access and private blob access
 - Uploaded files to the blob containers
 - Created a SAS token for a blob container
 - Verified that a web app has access to the files in the blob container



###Your feedback is important!  
As you ^['End'][howToEnd] your challenge, please take a few minutes to complete the short survey that will appear in the next window.

Alternatively, you may provide your feedback directly to challengefeedback@learnondemandsystems.com.

> [howToEnd]:
> To End your challenge, click the "hamburger" menu in the top right corner of these instructions and select **End**.
>
>!IMAGE[End.png](End.png)




Thank you and we look forward to your feedback.


